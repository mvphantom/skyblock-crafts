# Skyblock Crafts (Fabric 1.21.1)

Adds two crafting-table recipes:

| Recipe | Result | What you get back |
|---|---|---|
| Cobblestone + Stone Pickaxe | 1 Gravel | The pickaxe, with 1 durability used (it breaks when it runs out) |
| Dirt + Gravel + Water Bucket | 1 Clay block | The full water bucket |

Shift-click the output to craft a whole stack at once.

## Building the .jar

You need **Java 21** (the same Java that Minecraft 1.21.1 uses).

1. Unzip this folder.
2. Open a terminal in the folder.
3. Run:
   - Windows: `gradlew.bat build`
   - Mac/Linux: `./gradlew build`
4. The first build downloads Minecraft and the Fabric tools, so it takes a few minutes.
5. Your mod is `build/libs/skyblock-crafts-1.0.0.jar`. Put it in your `mods` folder.
   Fabric API is **not** required. Install it on both the client and the server.

## Tweaking the recipes

The recipes live in `src/main/resources/data/skyblockcrafts/recipe/`. Edit them and rebuild.

- `tool_damage`: how much durability the pickaxe loses per craft.
- `keep`: which item comes back unchanged.
- To let **any** pickaxe work, change the pickaxe line to
  `{ "tag": "minecraft:pickaxes" }`.
- To get clay balls instead of clay blocks, change `"minecraft:clay"` to
  `"minecraft:clay_ball"` (and maybe raise `count` to 4).

You can also override or add recipes with a normal datapack using
`"type": "skyblockcrafts:keep_shapeless"`.
