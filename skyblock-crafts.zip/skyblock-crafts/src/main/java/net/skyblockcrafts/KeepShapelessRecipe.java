package net.skyblockcrafts;

import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.recipe.Ingredient;
import net.minecraft.recipe.RecipeSerializer;
import net.minecraft.recipe.ShapelessRecipe;
import net.minecraft.recipe.book.CraftingRecipeCategory;
import net.minecraft.recipe.input.CraftingRecipeInput;
import net.minecraft.util.collection.DefaultedList;

/**
 * A normal shapeless crafting recipe with two extras:
 *  - "tool_damage": any damageable item in the grid (like a pickaxe) comes back
 *    with this much durability used, instead of being eaten. It breaks if it runs out.
 *  - "keep": items matching this ingredient (like a water bucket) come back unchanged.
 */
public class KeepShapelessRecipe extends ShapelessRecipe {
    private final String group;
    private final CraftingRecipeCategory category;
    private final ItemStack result;
    private final DefaultedList<Ingredient> ingredients;
    private final Ingredient keep;
    private final int toolDamage;

    public KeepShapelessRecipe(String group, CraftingRecipeCategory category, ItemStack result,
                               DefaultedList<Ingredient> ingredients, Ingredient keep, int toolDamage) {
        super(group, category, result, ingredients);
        this.group = group;
        this.category = category;
        this.result = result;
        this.ingredients = ingredients;
        this.keep = keep;
        this.toolDamage = toolDamage;
    }

    @Override
    public DefaultedList<ItemStack> getRemainder(CraftingRecipeInput input) {
        DefaultedList<ItemStack> remainders = DefaultedList.ofSize(input.getSize(), ItemStack.EMPTY);

        for (int i = 0; i < remainders.size(); i++) {
            ItemStack stack = input.getStackInSlot(i);
            if (stack.isEmpty()) {
                continue;
            }

            if (!keep.isEmpty() && keep.test(stack)) {
                // Give the item back exactly as it was (e.g. a full water bucket).
                remainders.set(i, stack.copyWithCount(1));
            } else if (toolDamage > 0 && stack.isDamageable()) {
                // Give the tool back with some durability used, or nothing if it breaks.
                ItemStack tool = stack.copyWithCount(1);
                int newDamage = tool.getDamage() + toolDamage;
                if (newDamage < tool.getMaxDamage()) {
                    tool.setDamage(newDamage);
                    remainders.set(i, tool);
                }
            } else {
                // Normal vanilla behaviour for everything else.
                Item item = stack.getItem();
                if (item.hasRecipeRemainder()) {
                    remainders.set(i, new ItemStack(item.getRecipeRemainder()));
                }
            }
        }
        return remainders;
    }

    @Override
    public RecipeSerializer<?> getSerializer() {
        return SERIALIZER;
    }

    public static final RecipeSerializer<KeepShapelessRecipe> SERIALIZER = new Serializer();

    public static class Serializer implements RecipeSerializer<KeepShapelessRecipe> {
        private static final MapCodec<KeepShapelessRecipe> CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
                Codec.STRING.optionalFieldOf("group", "").forGetter(r -> r.group),
                CraftingRecipeCategory.CODEC.fieldOf("category").orElse(CraftingRecipeCategory.MISC).forGetter(r -> r.category),
                ItemStack.VALIDATED_CODEC.fieldOf("result").forGetter(r -> r.result),
                Ingredient.DISALLOW_EMPTY_CODEC.listOf().fieldOf("ingredients").flatXmap(list -> {
                    Ingredient[] array = list.stream().filter(ing -> !ing.isEmpty()).toArray(Ingredient[]::new);
                    if (array.length == 0) {
                        return DataResult.<DefaultedList<Ingredient>>error(() -> "No ingredients for keep_shapeless recipe");
                    }
                    if (array.length > 9) {
                        return DataResult.<DefaultedList<Ingredient>>error(() -> "Too many ingredients for keep_shapeless recipe");
                    }
                    return DataResult.success(DefaultedList.copyOf(Ingredient.EMPTY, array));
                }, DataResult::success).forGetter(r -> r.ingredients),
                Ingredient.ALLOW_EMPTY_CODEC.optionalFieldOf("keep", Ingredient.EMPTY).forGetter(r -> r.keep),
                Codec.INT.optionalFieldOf("tool_damage", 0).forGetter(r -> r.toolDamage)
        ).apply(instance, KeepShapelessRecipe::new));

        private static final PacketCodec<RegistryByteBuf, KeepShapelessRecipe> PACKET_CODEC =
                PacketCodec.ofStatic(Serializer::write, Serializer::read);

        @Override
        public MapCodec<KeepShapelessRecipe> codec() {
            return CODEC;
        }

        @Override
        public PacketCodec<RegistryByteBuf, KeepShapelessRecipe> packetCodec() {
            return PACKET_CODEC;
        }

        private static KeepShapelessRecipe read(RegistryByteBuf buf) {
            String group = buf.readString();
            CraftingRecipeCategory category = buf.readEnumConstant(CraftingRecipeCategory.class);
            int count = buf.readVarInt();
            DefaultedList<Ingredient> ingredients = DefaultedList.ofSize(count, Ingredient.EMPTY);
            ingredients.replaceAll(ignored -> Ingredient.PACKET_CODEC.decode(buf));
            ItemStack result = ItemStack.PACKET_CODEC.decode(buf);
            Ingredient keep = Ingredient.PACKET_CODEC.decode(buf);
            int toolDamage = buf.readVarInt();
            return new KeepShapelessRecipe(group, category, result, ingredients, keep, toolDamage);
        }

        private static void write(RegistryByteBuf buf, KeepShapelessRecipe recipe) {
            buf.writeString(recipe.group);
            buf.writeEnumConstant(recipe.category);
            buf.writeVarInt(recipe.ingredients.size());
            for (Ingredient ingredient : recipe.ingredients) {
                Ingredient.PACKET_CODEC.encode(buf, ingredient);
            }
            ItemStack.PACKET_CODEC.encode(buf, recipe.result);
            Ingredient.PACKET_CODEC.encode(buf, recipe.keep);
            buf.writeVarInt(recipe.toolDamage);
        }
    }
}
