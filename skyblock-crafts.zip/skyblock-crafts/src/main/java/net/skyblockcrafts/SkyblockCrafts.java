package net.skyblockcrafts;

import net.fabricmc.api.ModInitializer;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public class SkyblockCrafts implements ModInitializer {
    public static final String MOD_ID = "skyblockcrafts";

    @Override
    public void onInitialize() {
        // Registers the "skyblockcrafts:keep_shapeless" recipe type used by the JSON recipes.
        Registry.register(
                Registries.RECIPE_SERIALIZER,
                Identifier.of(MOD_ID, "keep_shapeless"),
                KeepShapelessRecipe.SERIALIZER
        );
    }
}
